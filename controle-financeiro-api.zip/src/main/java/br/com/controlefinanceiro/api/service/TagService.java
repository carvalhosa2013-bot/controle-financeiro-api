package br.com.controlefinanceiro.api.service;

import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.entity.Tag;
import br.com.controlefinanceiro.api.repository.TagRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class TagService {
    private final TagRepository repository;
    public TagService(TagRepository repository) { this.repository = repository; }

    public TagResponse criar(TagRequest request) {
        String nome = request.nome().trim();
        if (repository.existsByNomeIgnoreCase(nome))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Tag já cadastrada");
        Tag tag = repository.save(new Tag(null, nome, null));
        return new TagResponse(tag.getId(), tag.getNome());
    }

    public List<TagResponse> listar() {
        return repository.findAll().stream().map(t -> new TagResponse(t.getId(), t.getNome())).toList();
    }
}
