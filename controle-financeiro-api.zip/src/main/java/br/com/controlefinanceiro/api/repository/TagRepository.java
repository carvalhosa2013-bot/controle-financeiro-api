package br.com.controlefinanceiro.api.repository;
import br.com.controlefinanceiro.api.entity.Tag;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TagRepository extends JpaRepository<Tag, Long> {
    boolean existsByNomeIgnoreCase(String nome);
}
