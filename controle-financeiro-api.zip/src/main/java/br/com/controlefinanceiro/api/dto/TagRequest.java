package br.com.controlefinanceiro.api.dto;
import jakarta.validation.constraints.NotBlank;
public record TagRequest(@NotBlank(message = "Nome da tag é obrigatório") String nome) {}
