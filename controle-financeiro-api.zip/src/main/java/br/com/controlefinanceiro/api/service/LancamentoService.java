package br.com.controlefinanceiro.api.service;

import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.entity.*;
import br.com.controlefinanceiro.api.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LancamentoService {
    private final LancamentoRepository lancamentoRepo;
    private final PerfilRepository perfilRepo;
    private final TagRepository tagRepo;

    public LancamentoService(LancamentoRepository l, PerfilRepository p, TagRepository t) {
        this.lancamentoRepo = l; this.perfilRepo = p; this.tagRepo = t;
    }

    public LancamentoResponse criar(LancamentoRequest r) {
        Perfil perfil = perfilRepo.findById(r.perfilId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Perfil não encontrado"));
        Set<Tag> tags = r.tagIds() == null ? new HashSet<>() : new HashSet<>(tagRepo.findAllById(r.tagIds()));
        if (r.tagIds() != null && tags.size() != r.tagIds().size())
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Uma ou mais tags não foram encontradas");

        Lancamento l = new Lancamento();
        l.setDescricao(r.descricao().trim()); l.setValor(r.valor()); l.setTipo(r.tipo());
        l.setData(r.data()); l.setPerfil(perfil); l.setTags(tags);
        return toResponse(lancamentoRepo.save(l));
    }

    public java.util.List<LancamentoResponse> listar() {
        return lancamentoRepo.findAll().stream().map(this::toResponse).toList();
    }

    private LancamentoResponse toResponse(Lancamento l) {
        return new LancamentoResponse(l.getId(), l.getDescricao(), l.getValor(), l.getTipo(),
            l.getData(), l.getPerfil().getId(),
            l.getTags().stream().map(Tag::getId).collect(Collectors.toSet()));
    }
}
