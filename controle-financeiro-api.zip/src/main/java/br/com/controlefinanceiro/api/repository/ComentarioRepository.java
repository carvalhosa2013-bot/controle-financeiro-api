package br.com.controlefinanceiro.api.repository;
import br.com.controlefinanceiro.api.entity.Comentario;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ComentarioRepository extends JpaRepository<Comentario, Long> {}
