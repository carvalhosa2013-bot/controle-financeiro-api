package br.com.controlefinanceiro.api.repository;
import br.com.controlefinanceiro.api.entity.Lancamento;
import org.springframework.data.jpa.repository.JpaRepository;
public interface LancamentoRepository extends JpaRepository<Lancamento, Long> {}
