package br.com.controlefinanceiro.api.repository;
import br.com.controlefinanceiro.api.entity.Perfil;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PerfilRepository extends JpaRepository<Perfil, Long> {
    boolean existsByEmail(String email);
}
