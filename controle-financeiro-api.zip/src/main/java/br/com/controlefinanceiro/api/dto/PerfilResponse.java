package br.com.controlefinanceiro.api.dto;
public record PerfilResponse(Long id, String nome, String email) {}
