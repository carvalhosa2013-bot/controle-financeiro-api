package br.com.controlefinanceiro.api.service;

import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.entity.Perfil;
import br.com.controlefinanceiro.api.repository.PerfilRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PerfilService {
    private final PerfilRepository repository;
    public PerfilService(PerfilRepository repository) { this.repository = repository; }

    public PerfilResponse criar(PerfilRequest request) {
        if (repository.existsByEmail(request.email()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "E-mail já cadastrado");
        Perfil p = new Perfil(null, request.nome().trim(), request.email().trim().toLowerCase(), null);
        return toResponse(repository.save(p));
    }

    public PerfilResponse buscar(Long id) {
        return repository.findById(id).map(this::toResponse)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Perfil não encontrado"));
    }

    private PerfilResponse toResponse(Perfil p) { return new PerfilResponse(p.getId(), p.getNome(), p.getEmail()); }
}
