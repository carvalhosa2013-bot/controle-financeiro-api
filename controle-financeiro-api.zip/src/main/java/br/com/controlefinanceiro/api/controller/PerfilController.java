package br.com.controlefinanceiro.api.controller;
import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.service.PerfilService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profiles")
public class PerfilController {
    private final PerfilService service;
    public PerfilController(PerfilService service) { this.service = service; }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public PerfilResponse criar(@Valid @RequestBody PerfilRequest request) { return service.criar(request); }

    @GetMapping("/{id}")
    public PerfilResponse buscar(@PathVariable Long id) { return service.buscar(id); }
}
