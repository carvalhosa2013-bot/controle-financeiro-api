package br.com.controlefinanceiro.api.controller;
import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.service.TagService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/technologies")
public class TagController {
    private final TagService service;
    public TagController(TagService service) { this.service = service; }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public TagResponse criar(@Valid @RequestBody TagRequest request) { return service.criar(request); }

    @GetMapping
    public List<TagResponse> listar() { return service.listar(); }
}
