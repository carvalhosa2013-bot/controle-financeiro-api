package br.com.controlefinanceiro.api.dto;

import br.com.controlefinanceiro.api.entity.TipoLancamento;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

public record LancamentoRequest(
    @NotBlank(message = "Descrição é obrigatória") String descricao,
    @NotNull(message = "Valor é obrigatório") @Positive(message = "Valor deve ser positivo") BigDecimal valor,
    @NotNull(message = "Tipo é obrigatório") TipoLancamento tipo,
    @NotNull(message = "Data é obrigatória") LocalDate data,
    @NotNull(message = "Perfil é obrigatório") Long perfilId,
    Set<Long> tagIds
) {}
