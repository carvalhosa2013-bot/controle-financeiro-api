package br.com.controlefinanceiro.api.controller;
import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.service.LancamentoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class LancamentoController {
    private final LancamentoService service;
    public LancamentoController(LancamentoService service) { this.service = service; }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public LancamentoResponse criar(@Valid @RequestBody LancamentoRequest request) { return service.criar(request); }

    @GetMapping
    public List<LancamentoResponse> listar() { return service.listar(); }
}
