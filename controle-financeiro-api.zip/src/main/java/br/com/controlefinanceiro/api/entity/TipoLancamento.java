package br.com.controlefinanceiro.api.entity;

public enum TipoLancamento {
    RECEITA, DESPESA
}
