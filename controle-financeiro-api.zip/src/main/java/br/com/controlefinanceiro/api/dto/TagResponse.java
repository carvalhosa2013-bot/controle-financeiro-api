package br.com.controlefinanceiro.api.dto;
public record TagResponse(Long id, String nome) {}
