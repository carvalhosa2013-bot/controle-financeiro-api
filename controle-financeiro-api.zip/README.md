# Controle Financeiro Pessoal — API REST

Projeto prático da primeira etapa: modelagem de domínio, persistência e endpoints básicos.

## Stack
- Java 17
- Spring Boot 3.5
- Spring Web
- Spring Data JPA
- Bean Validation
- H2 (execução/testes rápidos)
- PostgreSQL (dependência pronta para produção)
- Maven

## Modelagem
Para manter os relacionamentos solicitados e adaptá-los ao domínio financeiro:

| Modelo solicitado | Domínio financeiro |
|---|---|
| Profile | Perfil/usuário |
| Project | Lançamento financeiro |
| Technology | Tag |
| Feedback | Comentário |

Relacionamentos:
- Perfil 1:N Lançamento
- Lançamento N:N Tag
- Lançamento 1:N Comentário

## Endpoints
- POST `/api/profiles`
- GET `/api/profiles/{id}`
- POST `/api/technologies`
- GET `/api/technologies`
- POST `/api/projects`
- GET `/api/projects`

## Exemplos

### Criar perfil
```json
{"nome":"Maria Silva","email":"maria@email.com"}
```

### Criar tag
```json
{"nome":"Alimentação"}
```

### Criar lançamento
```json
{
  "descricao":"Supermercado",
  "valor":250.90,
  "tipo":"DESPESA",
  "data":"2026-09-25",
  "perfilId":1,
  "tagIds":[1]
}
```

## Executar
```bash
mvn spring-boot:run
```
API: `http://localhost:8080`

Console H2: `http://localhost:8080/h2-console`
JDBC URL: `jdbc:h2:mem:financeiro`
Usuário: `sa`
Senha: vazia

## GitHub
Depois de criar o repositório público, publique a pasta e substitua o link do PDF pelo endereço do seu repositório.
