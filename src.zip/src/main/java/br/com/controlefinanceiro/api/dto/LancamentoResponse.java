package br.com.controlefinanceiro.api.dto;

import br.com.controlefinanceiro.api.entity.TipoLancamento;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

public record LancamentoResponse(
    Long id, String descricao, BigDecimal valor, TipoLancamento tipo, LocalDate data,
    Long perfilId, Set<Long> tagIds, BigDecimal notaMedia,
    Integer quantidadeAvaliacoes, Integer upvotes) {}
