package br.com.controlefinanceiro.api.repository;

import br.com.controlefinanceiro.api.entity.Lancamento;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LancamentoRepository extends JpaRepository<Lancamento, Long> {
    Page<Lancamento> findAll(Pageable pageable);
    Page<Lancamento> findDistinctByTags_NomeIgnoreCase(String nome, Pageable pageable);
}
