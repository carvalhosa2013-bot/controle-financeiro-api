package br.com.controlefinanceiro.api.controller;

import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.service.LancamentoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/projects")
@Tag(name = "Lançamentos", description = "Operações financeiras da aplicação")
public class LancamentoController {
    private final LancamentoService service;

    public LancamentoController(LancamentoService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Cadastrar lançamento financeiro")
    public LancamentoResponse criar(@Valid @RequestBody LancamentoRequest request) {
        return service.criar(request);
    }

    @GetMapping
    @Operation(summary = "Listar lançamentos com filtro e paginação")
    public Page<LancamentoResponse> listar(
        @RequestParam(required = false) String tecnologia,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size) {
        return service.listar(tecnologia, page, size);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar lançamento")
    public LancamentoResponse atualizar(@PathVariable Long id, @Valid @RequestBody LancamentoRequest request) {
        return service.atualizar(id, request);
    }

    @PostMapping("/{id}/feedbacks")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Cadastrar avaliação de 1 a 5 e comentário")
    public FeedbackResponse feedback(@PathVariable Long id, @Valid @RequestBody FeedbackRequest request) {
        return service.adicionarFeedback(id, request);
    }

    @PutMapping("/{id}/upvote")
    @Operation(summary = "Incrementar curtidas/estrelas do lançamento")
    public LancamentoResponse upvote(@PathVariable Long id) {
        return service.upvote(id);
    }
}
