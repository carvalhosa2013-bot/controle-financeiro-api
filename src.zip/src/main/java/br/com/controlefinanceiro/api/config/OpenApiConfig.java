package br.com.controlefinanceiro.api.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI controleFinanceiroOpenAPI() {
        return new OpenAPI().info(new Info()
            .title("Controle Financeiro Pessoal API")
            .version("1.0.0")
            .description("API REST para gerenciamento de lançamentos, tags e avaliações."));
    }
}
