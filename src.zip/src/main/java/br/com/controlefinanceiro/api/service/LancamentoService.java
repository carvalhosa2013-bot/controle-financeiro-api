package br.com.controlefinanceiro.api.service;

import br.com.controlefinanceiro.api.dto.*;
import br.com.controlefinanceiro.api.entity.*;
import br.com.controlefinanceiro.api.repository.*;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LancamentoService {
    private final LancamentoRepository lancamentoRepo;
    private final PerfilRepository perfilRepo;
    private final TagRepository tagRepo;
    private final ComentarioRepository comentarioRepo;

    public LancamentoService(LancamentoRepository l, PerfilRepository p, TagRepository t,
                             ComentarioRepository c) {
        this.lancamentoRepo = l;
        this.perfilRepo = p;
        this.tagRepo = t;
        this.comentarioRepo = c;
    }

    @Transactional
    public LancamentoResponse criar(LancamentoRequest r) {
        Perfil perfil = perfilRepo.findById(r.perfilId())
            .orElseThrow(() -> notFound("Perfil não encontrado"));

        Set<Tag> tags = buscarTags(r.tagIds());

        Lancamento l = new Lancamento();
        preencher(l, r, perfil, tags);
        return toResponse(lancamentoRepo.save(l));
    }

    @Transactional(readOnly = true)
    public Page<LancamentoResponse> listar(String tecnologia, int page, int size) {
        validarPaginacao(page, size);
        Pageable pageable = PageRequest.of(page, size, Sort.by("data").descending());
        Page<Lancamento> resultado = (tecnologia == null || tecnologia.isBlank())
            ? lancamentoRepo.findAll(pageable)
            : lancamentoRepo.findDistinctByTags_NomeIgnoreCase(tecnologia.trim(), pageable);
        return resultado.map(this::toResponse);
    }

    @Transactional
    public LancamentoResponse atualizar(Long id, LancamentoRequest r) {
        Lancamento l = buscarEntidade(id);
        Perfil perfil = perfilRepo.findById(r.perfilId())
            .orElseThrow(() -> notFound("Perfil não encontrado"));
        preencher(l, r, perfil, buscarTags(r.tagIds()));
        return toResponse(lancamentoRepo.save(l));
    }

    @Transactional
    public FeedbackResponse adicionarFeedback(Long id, FeedbackRequest request) {
        Lancamento l = buscarEntidade(id);

        Comentario comentario = new Comentario();
        comentario.setNota(request.nota());
        comentario.setTexto(request.comentario().trim());
        comentario.setLancamento(l);
        comentarioRepo.save(comentario);

        BigDecimal media = comentarioRepo.calcularMedia(id)
            .setScale(2, RoundingMode.HALF_UP);
        int quantidade = Math.toIntExact(comentarioRepo.countByLancamentoId(id));

        l.setNotaMedia(media);
        l.setQuantidadeAvaliacoes(quantidade);
        lancamentoRepo.save(l);

        return new FeedbackResponse(comentario.getId(), id, comentario.getNota(), comentario.getTexto());
    }

    @Transactional
    public LancamentoResponse upvote(Long id) {
        Lancamento l = buscarEntidade(id);
        l.setUpvotes(l.getUpvotes() + 1);
        return toResponse(lancamentoRepo.save(l));
    }

    private Lancamento buscarEntidade(Long id) {
        return lancamentoRepo.findById(id)
            .orElseThrow(() -> notFound("Lançamento não encontrado"));
    }

    private Set<Tag> buscarTags(Set<Long> ids) {
        if (ids == null || ids.isEmpty()) return new HashSet<>();
        Set<Tag> tags = new HashSet<>(tagRepo.findAllById(ids));
        if (tags.size() != ids.size())
            throw notFound("Uma ou mais tags não foram encontradas");
        return tags;
    }

    private void preencher(Lancamento l, LancamentoRequest r, Perfil perfil, Set<Tag> tags) {
        l.setDescricao(r.descricao().trim());
        l.setValor(r.valor());
        l.setTipo(r.tipo());
        l.setData(r.data());
        l.setPerfil(perfil);
        l.setTags(tags);
        if (l.getNotaMedia() == null) l.setNotaMedia(BigDecimal.ZERO);
        if (l.getQuantidadeAvaliacoes() == null) l.setQuantidadeAvaliacoes(0);
        if (l.getUpvotes() == null) l.setUpvotes(0);
    }

    private LancamentoResponse toResponse(Lancamento l) {
        return new LancamentoResponse(
            l.getId(), l.getDescricao(), l.getValor(), l.getTipo(), l.getData(),
            l.getPerfil().getId(),
            l.getTags().stream().map(Tag::getId).collect(Collectors.toSet()),
            l.getNotaMedia(), l.getQuantidadeAvaliacoes(), l.getUpvotes());
    }

    private void validarPaginacao(int page, int size) {
        if (page < 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Página deve ser maior ou igual a 0");
        if (size < 1 || size > 100)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tamanho deve estar entre 1 e 100");
    }

    private ResponseStatusException notFound(String message) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, message);
    }
}
