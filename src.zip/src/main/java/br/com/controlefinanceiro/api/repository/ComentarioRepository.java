package br.com.controlefinanceiro.api.repository;

import br.com.controlefinanceiro.api.entity.Comentario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

public interface ComentarioRepository extends JpaRepository<Comentario, Long> {
    @Query("select coalesce(avg(c.nota), 0) from Comentario c where c.lancamento.id = :lancamentoId")
    BigDecimal calcularMedia(@Param("lancamentoId") Long lancamentoId);

    long countByLancamentoId(Long lancamentoId);
}
