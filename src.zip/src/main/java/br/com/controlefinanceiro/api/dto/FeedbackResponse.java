package br.com.controlefinanceiro.api.dto;

public record FeedbackResponse(Long id, Long lancamentoId, Integer nota, String comentario) {}
