package br.com.controlefinanceiro.api.dto;

import jakarta.validation.constraints.*;

public record FeedbackRequest(
    @NotNull(message = "Nota é obrigatória")
    @Min(value = 1, message = "A nota deve ser de 1 a 5")
    @Max(value = 5, message = "A nota deve ser de 1 a 5")
    Integer nota,

    @NotBlank(message = "Comentário é obrigatório")
    @Size(max = 500, message = "Comentário deve ter no máximo 500 caracteres")
    String comentario
) {}
